#ifndef GRAPH_H
#define GRAPH_H
#include "utils.h"
class WebGraph
{
public:
    WebGraph();
    ~WebGraph();
    WebNode* nodes;
    unsigned int nodecount;
};
#endif // GRAPH_H
